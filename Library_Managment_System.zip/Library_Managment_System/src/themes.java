

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ALI HAIDER
 */
public class themes extends javax.swing.JPanel {

    /**
     * Creates new form accounts_information_panel
     */
    DefaultTableModel model;
    
     public  void loadTable() throws SQLException
    {
       Connection con;
        
           con = databaseconnetion.get_Connection();
           this.model = (DefaultTableModel) accounts_table.getModel();
           accounts_table = new JTable(model);
           model.setRowCount(0);
           try{
               Statement st = con.createStatement();
               ResultSet rs = st.executeQuery("SELECT * FROM theme");
               while(rs.next())
               {
                   String[] data=new String[2];
                   data[0]=rs.getString(1);
                   data[1]=rs.getString(2);
                   
                   model.addRow(data);
               }     
           }
           catch(Exception ex)
           {
               JOptionPane.showMessageDialog(null, "Cannot Create Statement Exception Catched    :    " + ex.getMessage() + "      ", "Themes Information", JOptionPane.ERROR_MESSAGE);
               
           }
        
        
    }
     Connection con;
    public themes() {
    
           initComponents();
           con=databaseconnetion.get_Connection();
           t2.requestFocus();
           try {
               loadTable();
           } catch (SQLException ex) {
               Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
           }
   
        
    }
    
    
    public void search_data()
    {
      
model.setRowCount(0);
ResultSet rs;
String str = null;

if(chk1.isSelected() ==false && chk2.isSelected() ==false)
{
    search.setText("");
    try {
        loadTable();
    } catch (SQLException ex) {
        Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
    }
    search.grabFocus();
    JOptionPane.showMessageDialog(null,"             Please Check Any Of the Given CheckBox To Search Accordingly . . .                             ","Themes Information",JOptionPane.WARNING_MESSAGE); 

}
else
    if(chk1.isSelected())
{
    str=search.getText();
 
    try {
        loadTable("theme_id ",str);
    } catch (SQLException ex) {
        Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
    }
  
}
else if (chk2.isSelected())
{
str=search.getText();
    
    try {
        loadTable("name",str);
    } catch (SQLException ex) {
        Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
    }
   
}    

    }
    
    public void delete()
    {
        if(t1.getText().equals("00"))
{
    
            JOptionPane.showMessageDialog(null, "     Kindly Select Some Data Row From The Table To Delete   . . .                   ", "Themes Information", JOptionPane.ERROR_MESSAGE);

}
else
{
            try {
                Statement st = con.createStatement();
                st.executeUpdate("DELETE FROM theme  WHERE theme_id = '"+t1.getText()+"' ");
                t1.setText("00");
                t2.setText("");
            

                t2.grabFocus();
                loadTable();
                JOptionPane.showMessageDialog(null, "Theme Deleted From DataBase SuccessFully . . .           \n          ", "Themes Information", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null," Exception         "+ex.getMessage()+"           ","Themes Information",JOptionPane.WARNING_MESSAGE);
           
        }      
}   
        
        
    }
    
     public void delete(int last)
    {
        
        
         int i = JOptionPane.showConfirmDialog(null,"Do you Really Want To Delete Last Theme ? \n  ","Themes Information",JOptionPane.YES_NO_OPTION);
 if(i == JOptionPane.YES_OPTION )
 {
     
     
     if(t1.getText().equals("00"))
{
    
            JOptionPane.showMessageDialog(null, "     Kindly Select Some Data Row From The Table To Delete   . . .                   ", "Themes Information", JOptionPane.ERROR_MESSAGE);

}
else
{
            try {
                Statement st = con.createStatement();
                st.executeUpdate("DELETE FROM theme  WHERE theme_id = '"+t1.getText()+"' ");
                t1.setText("00");
                t2.setText("");
               
                t2.grabFocus();
                loadTable();
                Home.jButton6.doClick();
                JOptionPane.showMessageDialog(null, "Last Theme Deleted From DataBase SuccessFully . . .           \nPlease Create New Themes  to procceed further             ", "Themes Information", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null," Exception         "+ex.getMessage()+"           ","Themes Information",JOptionPane.WARNING_MESSAGE);
           
        }      
}   
        
     
     
     
 }
        
        
        
    }
    
    public  void loadTable(String databaseColumn,String givenargument) throws SQLException
    {
    this.model = (DefaultTableModel) accounts_table.getModel();
    accounts_table= new JTable(model);
       try{
        Statement st = con.createStatement();
        
        ResultSet rs = st.executeQuery("SELECT * FROM theme WHERE Binary "+databaseColumn+" LIKE Binary'%"+givenargument+"%'");
          
            while(rs.next())
            {
                   String[] data=new String[2];
                   data[0]=rs.getString(1);
                   data[1]=rs.getString(2);
                
                model.addRow(data);
            }
       
       }
       catch(Exception ex)
       {
        JOptionPane.showMessageDialog(null," Exception         "+ex.getMessage()+"           ","Themes Information",JOptionPane.WARNING_MESSAGE);

       }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        t2 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        search = new javax.swing.JTextField();
        chk2 = new javax.swing.JCheckBox();
        chk1 = new javax.swing.JCheckBox();
        jLabel9 = new javax.swing.JLabel();
        t1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        accounts_table = new javax.swing.JTable();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(1002, 688));

        jPanel1.setBackground(new java.awt.Color(243, 243, 243));
        jPanel1.setPreferredSize(new java.awt.Dimension(0, 686));

        jLabel1.setFont(new java.awt.Font("Rockwell", 0, 28)); // NOI18N
        jLabel1.setText("Books Themes Interface");

        jLabel2.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel2.setText("Theme /Topic Name ");

        jLabel4.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        jLabel4.setText("THEME ID");

        t2.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        t2.setSelectionColor(new java.awt.Color(19, 80, 161));
        t2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                t2KeyPressed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/insert.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.setContentAreaFilled(false);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/update.png"))); // NOI18N
        jButton2.setBorder(null);
        jButton2.setContentAreaFilled(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/deleteIcon.png"))); // NOI18N
        jButton3.setText("Delete Selected");
        jButton3.setBorder(null);
        jButton3.setContentAreaFilled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/garbage-bin-png-10496.png"))); // NOI18N
        jButton4.setText("Delete all");
        jButton4.setBorder(null);
        jButton4.setContentAreaFilled(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/refersh.png"))); // NOI18N
        jButton5.setText("Refresh ");
        jButton5.setBorder(null);
        jButton5.setContentAreaFilled(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        jLabel8.setText("Search Themes");
        jLabel8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel8.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        search.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        search.setSelectionColor(new java.awt.Color(19, 80, 161));
        search.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchFocusLost(evt);
            }
        });
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchKeyReleased(evt);
            }
        });

        chk2.setBackground(new java.awt.Color(243, 243, 243));
        chk2.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        chk2.setText("Search by Name");
        chk2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk2ActionPerformed(evt);
            }
        });

        chk1.setBackground(new java.awt.Color(243, 243, 243));
        chk1.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        chk1.setText("Search by Theme Id");
        chk1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk1ActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        jLabel9.setText("Themes/Topics  List");

        t1.setFont(new java.awt.Font("Rockwell", 0, 20)); // NOI18N
        t1.setForeground(new java.awt.Color(247, 147, 29));
        t1.setText("00");

        jPanel2.setBackground(new java.awt.Color(251, 152, 200));
        jPanel2.setOpaque(false);

        accounts_table.setAutoCreateRowSorter(true);
        accounts_table.setFont(new java.awt.Font("Rockwell", 0, 13)); // NOI18N
        accounts_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Theme ID", "Theme Name"
            }
        ));
        accounts_table.setGridColor(new java.awt.Color(0, 0, 0));
        accounts_table.setSelectionBackground(new java.awt.Color(247, 147, 29));
        accounts_table.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                accounts_tableFocusLost(evt);
            }
        });
        accounts_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                accounts_tableMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(accounts_table);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 548, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(t2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(chk2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(chk1, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(176, 176, 176)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(184, 184, 184))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addGap(31, 31, 31)
                .addComponent(jButton3)
                .addGap(42, 42, 42))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(203, 203, 203)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(47, 47, 47)
                .addComponent(jLabel9)
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(chk1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(chk2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(t1))
                        .addGap(37, 37, 37)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(t2)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(75, 75, 75)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(130, 130, 130))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(20, 20, 20))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 957, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 45, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 750, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       
        t1.setText("00");
        t2.setText("");
     
        search.setText("");
        t2.grabFocus();
        chk1.setSelected(false);
         chk2.setSelected(false);
        try {
            loadTable();        // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 if(t2.getText().equals("") )
        JOptionPane.showMessageDialog(null,"           Please Fill All The Required Fields   !              ","Themes Information",JOptionPane.WARNING_MESSAGE);
       
else
{
      
{// TODO add your handling code here:
    
    
    
    
Statement stt;
ResultSet rs = null;
          try {
              stt = con.createStatement();
                 rs = stt.executeQuery("SELECT * From theme where name='"+t2.getText()+"'   ");

          } catch (Exception ex) {
              Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
          }
          
          try {
              if(rs.next())
              {
                  
                  JOptionPane.showMessageDialog(null,"\t\tTheme with Such Creadetials Already Exits Please Try with other Credentials!\t\t","Themes Information",JOptionPane.ERROR_MESSAGE);
                  
              }  else
          {
                            
Statement st;

          try {
              st = con.createStatement();
                st.executeUpdate("INSERT INTO theme (name) VALUES  ('"+t2.getText()+"')");

          } catch (Exception ex) {
              Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
          }
                  
                  
                t1.setText("00");
                t2.setText("");
             
                t2.grabFocus();
          try {  
              loadTable();
          } catch (SQLException ex) {
              Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
          }
JOptionPane.showMessageDialog(null,"           Theme is added Successfully  !              ","Themes Information",JOptionPane.INFORMATION_MESSAGE);

                  
                  
                  }  } catch (SQLException ex) {
              Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
          }
          
        
          
          
}
 
        }


    }//GEN-LAST:event_jButton1ActionPerformed

    private void accounts_tableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_accounts_tableMouseReleased
try{
      search.setText("");
        chk1.setSelected(false);
        chk2.setSelected(false);
        int i = accounts_table.rowAtPoint(evt.getPoint());// TODO add your handling code here       
        
        String serial =(String) accounts_table.getValueAt(i,0);
        String name =( accounts_table.getValueAt(i,1)).toString();
   
        
        t1.setText(serial);
        t2.setText(name);
   
        try {
            loadTable();
            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
        }
}
catch(Exception ex )
{
    JOptionPane.showMessageDialog(null,"           Please  Select Only Single Row to Perform Operations  !          ","Themes Information",JOptionPane.WARNING_MESSAGE);
    try {
        loadTable();
        // TODO add your handling code here:
    } catch (SQLException ex1) {
        Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex1);
    }
        

}


      
    }//GEN-LAST:event_accounts_tableMouseReleased

    private void t2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_t2KeyPressed
         // TODO add your handling code here:
    }//GEN-LAST:event_t2KeyPressed

    private void searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyReleased
search_data();
// TODO add your handling code here:
    }//GEN-LAST:event_searchKeyReleased

    private void chk2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk2ActionPerformed
chk1.setSelected(false);
search.grabFocus();// TODO add your handling code here:
    }//GEN-LAST:event_chk2ActionPerformed

    private void chk1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk1ActionPerformed

chk2.setSelected(false);   
search.grabFocus();
// TODO add your handling code here:
    }//GEN-LAST:event_chk1ActionPerformed

    private void searchFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFocusLost
       
            chk2.setSelected(false);
            chk1.setSelected(false);
            search.setText("");
     
    }//GEN-LAST:event_searchFocusLost

    private void searchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFocusGained
t1.setText("00");   
t2.setText("");
 
        try {
            loadTable();
            
            
// TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_searchFocusGained

    private void accounts_tableFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_accounts_tableFocusLost
        try {
            loadTable();        // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_accounts_tableFocusLost

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
if(t1.getText().equals("00"))
{
    
            JOptionPane.showMessageDialog(null, "     Kindly Select Some Data Row From The Table To Update   . . .                   ", "Themes Information", JOptionPane.ERROR_MESSAGE);

}
else
{
        if(t2.getText().equals("") )
        JOptionPane.showMessageDialog(null,"           Please Fill All The Required Fields   !              ","Themes Information",JOptionPane.ERROR_MESSAGE);
        else
        {
            try {
                Statement st = con.createStatement();
                st.executeUpdate("UPDATE theme SET name='"+t2.getText()+"'   WHERE theme_id ='"+t1.getText()+"'")
                        ;
                t1.setText("00");
                t2.setText("");
             
                t2.grabFocus();
                loadTable();
JOptionPane.showMessageDialog(null,"             your Theme Has Been Updated With New Inforamtion   !              ","Themes Information",JOptionPane.INFORMATION_MESSAGE);


            } catch (Exception ex)
            {
        JOptionPane.showMessageDialog(null," Exception         "+ex.getMessage()+"           ","Themes Information",JOptionPane.WARNING_MESSAGE);

            }

        }       }         }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
   if(t1.getText().equals("00"))
{
    
            JOptionPane.showMessageDialog(null, "     Kindly Select Some Data Row From The Table To Delete   . . .                   ", "Themes Information", JOptionPane.ERROR_MESSAGE);

}
else
if(accounts_table.getRowCount()== 1 && (t1.getText().equals("00")==false) )
{
    delete(1);
}    
else
{
delete();    
}

   

  // TODO add your handling code here:        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
try { 
             loadTable();
         } catch (SQLException ex) {
             Logger.getLogger(tests_panel.class.getName()).log(Level.SEVERE, null, ex);
         }
         if(accounts_table.getRowCount()==0)
         {
          JOptionPane.showMessageDialog(null, "All  Themes Information Has Already Deleted From The DataBase .                  ", "Themes Information", JOptionPane.INFORMATION_MESSAGE);

         }
         else{                                        
int i = JOptionPane.showConfirmDialog(null,"Do you Really Want To Delete All The Theme       ?  ","Themes Information",JOptionPane.YES_NO_OPTION);
 if(i == JOptionPane.YES_OPTION )
 {
    try {
        Statement st;
        st = con.createStatement();
        st.executeUpdate("DELETE FROM theme");
         t1.setText("00");
        t2.setText("");
       
        search.setText("");
        t2.grabFocus();
        chk1.setSelected(false);
         chk2.setSelected(false);
        loadTable();
     
        JOptionPane.showMessageDialog(null, "All Themes Has Been Deleted From The DataBase SuccessFully. \nPlease Create New Themes and then add books                 ", "Themes Information", JOptionPane.INFORMATION_MESSAGE);
    } catch (SQLException ex) {
        Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
    }
        

   
 }
 else;      
         }// TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JTable accounts_table;
    private javax.swing.JCheckBox chk1;
    private javax.swing.JCheckBox chk2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField search;
    private javax.swing.JLabel t1;
    public static javax.swing.JTextField t2;
    // End of variables declaration//GEN-END:variables
}
