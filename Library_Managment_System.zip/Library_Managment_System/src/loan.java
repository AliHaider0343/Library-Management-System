

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ALI HAIDER
 */
public class loan extends javax.swing.JPanel {

    /**
     * Creates new form accounts_information_panel
     */
    DefaultTableModel model;
    
     public  void loadTable() throws SQLException
    {
       Connection con;
        
           con = databaseconnetion.get_Connection();
           this.model = (DefaultTableModel) accounts_table.getModel();
           accounts_table = new JTable(model);
           model.setRowCount(0);
           try{
               Statement st = con.createStatement();
               
               ResultSet rs = st.executeQuery("select l.Loan_id,u.name,(select b.title from book b where b.book_id=c.book_id),`loan_date`_date,l.return_date from loan l join user u on u.user_id=l.user_id join copy c on c.copy_id=l.copy_id");
               while(rs.next())
               {
                   String[] data=new String[5];
                   data[0]=rs.getString(1);
                   data[1]=rs.getString(2);
                   data[2]=rs.getString(3);
                   data[3]=rs.getString(4);
                   data[4]=rs.getString(5);
           
                   model.addRow(data);
               }     
           }
           catch(Exception ex)
           {
               JOptionPane.showMessageDialog(null, "Cannot Create Statement Exception Catched    :    " + ex + "      ", "Loan Information", JOptionPane.ERROR_MESSAGE);
               
           }
        
        
    }
     
     
     
     
     public   void load_themes()
    {
        books.removeAllItems();
        
         try {
             Statement st = con.createStatement(); 
             ResultSet rs = st.executeQuery("SELECT * FROM book");
            books.addItem("Select Book Title");
             while(rs.next())
             {
              String element = rs.getString(2);
              books.addItem(element);    
             }
     
         } catch (SQLException ex) {
             Logger.getLogger(tests_panel.class.getName()).log(Level.SEVERE, null, ex);
         }
        
    }
     
        
     public   void load_users()
    {
        users.removeAllItems();
        
         try {
             Statement st = con.createStatement(); 
             ResultSet rs = st.executeQuery("SELECT * FROM user");
            users.addItem("Select User");
             while(rs.next())
             {
              String element = rs.getString(2);
              users.addItem(element);    
             }
     
         } catch (SQLException ex) {
             Logger.getLogger(tests_panel.class.getName()).log(Level.SEVERE, null, ex);
         }
        
    }
     
     
     
     
     
     
     Connection con;
    public loan() {
    
           initComponents();
           con=databaseconnetion.get_Connection();
           users.grabFocus();
                   load_themes();
      load_users();
      
        books.setSelectedIndex(0);
        users.setSelectedIndex(0);
           try {
               loadTable();
           } catch (SQLException ex) {
               Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
           }
   
        
    }
    
    
    public void search_data()
    {
      
model.setRowCount(0);
ResultSet rs;
String str = null;

if(chk1.isSelected() ==false && chk2.isSelected() ==false)
{
    search.setText("");
    try {
        loadTable();
    } catch (SQLException ex) {
        Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
    }
    search.grabFocus();
    JOptionPane.showMessageDialog(null,"             Please Check Any Of the Given CheckBox To Search Accordingly . . .                             ","Copy Information",JOptionPane.WARNING_MESSAGE); 

}
else
    if(chk2.isSelected())
{
    str=search.getText();
    try {
        loadTable("l.Loan_id",str);
    } catch (SQLException ex) {
        Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
    }
}
else if (chk1.isSelected())
{
     str=search.getText();

    try {
        loadTable2("u.name",str);
    } catch (SQLException ex) {
        Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
    }
   
}    

    }
    
    public void delete()
    {
        if(t1.getText().equals("00"))
{
    
            JOptionPane.showMessageDialog(null, "     Kindly Select Some Data Row From The Table To Delete   . . .                   ", "Loan Information", JOptionPane.ERROR_MESSAGE);

}
else
{
            try {
                Statement st = con.createStatement();
                st.executeUpdate("DELETE FROM loan  WHERE loan_id = '"+t1.getText()+"' ");
                  
                t1.setText("00");
                
                
                   load_themes();  load_users();
               load_users();
      books.setSelectedIndex(0);
           users.setSelectedIndex(0);

           
                loadTable();
                JOptionPane.showMessageDialog(null, "Loan Deleted From DataBase SuccessFully . . .           \n          ", "Loan Information", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null," Exception         "+ex.getMessage()+"           ","Loan Information",JOptionPane.WARNING_MESSAGE);
           
        }      
}   
        
        
    }
    
     public void delete(int last)
    {
        
        
         int i = JOptionPane.showConfirmDialog(null,"Do you Really Want To Delete Last Loan ? \n  ","Loan Information",JOptionPane.YES_NO_OPTION);
 if(i == JOptionPane.YES_OPTION )
 {
     
     
     if(t1.getText().equals("00"))
{
    
            JOptionPane.showMessageDialog(null, "     Kindly Select Some Data Row From The Table To Delete   . . .                   ", "Loan Information", JOptionPane.ERROR_MESSAGE);

}
else
{
            try {
                Statement st = con.createStatement();
                st.executeUpdate("DELETE FROM loan  WHERE loan_id  = '"+t1.getText()+"' ");
                
                t1.setText("00");
                
           
                   load_themes();  load_users();
           
 books.setSelectedIndex(0);
           users.setSelectedIndex(0);                 
                loadTable();
                Home.jButton6.doClick();
                JOptionPane.showMessageDialog(null, "Last Loan Deleted From DataBase SuccessFully . . .           \n             ", "Loan Information", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null," Exception         "+ex.getMessage()+"           ","Loan Information",JOptionPane.WARNING_MESSAGE);
           
        }      
}   
        
     
     
     
 }
        
        
        
    }
    
    public  void loadTable(String databaseColumn,String givenargument) throws SQLException
    {
    this.model = (DefaultTableModel) accounts_table.getModel();
    accounts_table= new JTable(model);
       try{
        Statement st = con.createStatement();
        
        
         ResultSet rs = st.executeQuery("select l.Loan_id,u.name,(select b.title from book b where b.book_id=c.book_id),`loan_date`_date,l.return_date from loan l join user u on u.user_id=l.user_id join copy c on c.copy_id=l.copy_id where loan_id = '"+givenargument+"'");          
            while(rs.next())
            {
                   String[] data=new String[5];
                   data[0]=rs.getString(1);
                   data[1]=rs.getString(2);
                   data[2]=rs.getString(3);
                   data[3]=rs.getString(4);
                   data[4]=rs.getString(5);
                    model.addRow(data);
            }
       
       }
       catch(Exception ex)
       {
        JOptionPane.showMessageDialog(null," Exception         "+ex.getMessage()+"           ","Books Information",JOptionPane.WARNING_MESSAGE);

       }
    }
 public  void loadTable2(String databaseColumn,String givenargument) throws SQLException
    {
    this.model = (DefaultTableModel) accounts_table.getModel();
    accounts_table= new JTable(model);
       try{
        Statement st = con.createStatement();
         ResultSet rs = st.executeQuery(" select l.Loan_id,u.name,(select b.title from book b where b.book_id=c.book_id),`loan_date`_date,l.return_date from loan l join user u on u.user_id=l.user_id join copy c on c.copy_id=l.copy_id where binary u.name LIKE Binary '%"+givenargument+"%' ");
         while(rs.next())
            {
                  String[] data=new String[5];
                   data[0]=rs.getString(1);
                   data[1]=rs.getString(2);
                   data[2]=rs.getString(3);
                   data[3]=rs.getString(4);
                   data[4]=rs.getString(5);
                   model.addRow(data);
            }
       
       }
       catch(Exception ex)
       {
        JOptionPane.showMessageDialog(null," Exception         "+ex.getMessage()+"           ","Books Information",JOptionPane.WARNING_MESSAGE);

       }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        search = new javax.swing.JTextField();
        chk2 = new javax.swing.JCheckBox();
        chk1 = new javax.swing.JCheckBox();
        jLabel9 = new javax.swing.JLabel();
        t1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        accounts_table = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        books = new javax.swing.JComboBox<>();
        ld = new com.toedter.calendar.JDateChooser();
        rd = new com.toedter.calendar.JDateChooser();
        users = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(1002, 688));

        jPanel1.setBackground(new java.awt.Color(243, 243, 243));
        jPanel1.setPreferredSize(new java.awt.Dimension(0, 686));

        jLabel1.setFont(new java.awt.Font("Rockwell", 0, 28)); // NOI18N
        jLabel1.setText("Books Loans/Borrow Interface");

        jLabel4.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        jLabel4.setText("LOAN ID");

        jLabel6.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel6.setText("User");

        jButton1.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/insert.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.setContentAreaFilled(false);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/update.png"))); // NOI18N
        jButton2.setBorder(null);
        jButton2.setContentAreaFilled(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/refersh.png"))); // NOI18N
        jButton5.setText("Refresh ");
        jButton5.setBorder(null);
        jButton5.setContentAreaFilled(false);
        jButton5.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        jLabel8.setText("Search Loan");
        jLabel8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel8.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        search.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        search.setSelectionColor(new java.awt.Color(19, 80, 161));
        search.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchFocusLost(evt);
            }
        });
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchKeyReleased(evt);
            }
        });

        chk2.setBackground(new java.awt.Color(243, 243, 243));
        chk2.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        chk2.setText("Search by Loan_id");
        chk2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk2ActionPerformed(evt);
            }
        });

        chk1.setBackground(new java.awt.Color(243, 243, 243));
        chk1.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        chk1.setText("Search by User name");
        chk1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chk1ActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        jLabel9.setText("Books Loans List");

        t1.setFont(new java.awt.Font("Rockwell", 0, 20)); // NOI18N
        t1.setForeground(new java.awt.Color(247, 147, 29));
        t1.setText("00");

        jPanel2.setBackground(new java.awt.Color(251, 152, 200));
        jPanel2.setOpaque(false);

        accounts_table.setAutoCreateRowSorter(true);
        accounts_table.setFont(new java.awt.Font("Rockwell", 0, 13)); // NOI18N
        accounts_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Loan ID", "User", "Copy of", "Loan date", "Return Date"
            }
        ));
        accounts_table.setGridColor(new java.awt.Color(0, 0, 0));
        accounts_table.setSelectionBackground(new java.awt.Color(247, 147, 29));
        accounts_table.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                accounts_tableFocusLost(evt);
            }
        });
        accounts_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                accounts_tableMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                accounts_tableMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(accounts_table);

        jButton3.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/deleteIcon.png"))); // NOI18N
        jButton3.setText("Delete Selected");
        jButton3.setBorder(null);
        jButton3.setContentAreaFilled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/garbage-bin-png-10496.png"))); // NOI18N
        jButton4.setText("Delete All ");
        jButton4.setBorder(null);
        jButton4.setContentAreaFilled(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 580, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 477, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addContainerGap())
        );

        books.setBackground(new java.awt.Color(247, 147, 29));
        books.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        books.setBorder(null);
        books.setOpaque(false);
        books.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                booksKeyPressed(evt);
            }
        });

        users.setBackground(new java.awt.Color(247, 147, 29));
        users.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        users.setBorder(null);
        users.setOpaque(false);
        users.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usersActionPerformed(evt);
            }
        });
        users.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                usersKeyPressed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel7.setText("Copy of");

        jLabel10.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel10.setText("Loan Date");

        jLabel11.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jLabel11.setText("Return date");

        jButton6.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/bks.png"))); // NOI18N
        jButton6.setText("View Avaiable Books");
        jButton6.setContentAreaFilled(false);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(users, 0, 173, Short.MAX_VALUE)
                            .addComponent(books, 0, 173, Short.MAX_VALUE)
                            .addComponent(rd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ld, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(chk2, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(chk1, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(19, 19, 19)
                                        .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jButton1))))
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(19, 19, 19)))
                        .addGap(123, 123, 123)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {books, users});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(65, 65, 65)
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(chk2, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(chk1)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(t1, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE))
                        .addGap(19, 19, 19)
                        .addComponent(jButton6)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(users, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(books, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ld, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(rd, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(123, 123, 123))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {books, users});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 957, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 45, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 750, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       
        t1.setText("00");
         
  load_themes();  load_users();
 books.setSelectedIndex(0);
           users.setSelectedIndex(0);        search.setText("");
         
        chk1.setSelected(false);
         chk2.setSelected(false);
        try {
            loadTable();        // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

   public int get_ids(String table_name,String column,String givenargument)
   {
       String result="";
        try {
            Statement st= con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM "+table_name+" WHERE binary "+column+" = '"+givenargument+"' ");
            if(rs.next())
             result=rs.getString(1);
        } catch (SQLException ex) {
            Logger.getLogger(books.class.getName()).log(Level.SEVERE, null, ex);
        }
          
      return Integer.parseInt(result);
   }
   
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
 if( users.getSelectedIndex()==0|| books.getSelectedIndex()==0  )
        JOptionPane.showMessageDialog(null,"           Please Fill All The Required Fields   !              ","Loan Information",JOptionPane.WARNING_MESSAGE);
       
else
{
    
  int edit1=get_ids( "book", "title", books.getSelectedItem().toString()  );
   
 int copy_id=get_ids(  "copy", "book_id",String.valueOf(edit1));
 
 int userId=get_ids(  "user", "name", users.getSelectedItem().toString()  );

      
    {
          
    
                 Statement st,st2,st1;
              
                 try {
                     
                     int b_id=0;
st = con.createStatement();

SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
    String fdate=df1.format(ld.getDate());
    
    SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
    String tdate=df2.format(rd.getDate());
    
st.executeUpdate("INSERT INTO loan (user_id, copy_id,loan_date,return_date) VALUES  ('"+userId+"','"+copy_id+"','"+fdate+"','"+tdate+"')");
                     
                   
                     
                 } catch (Exception ex) {
                     Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
                 }
                 
                 
                 t1.setText("00");
                 
                  
                 load_themes();  load_users();
                
 books.setSelectedIndex(0);
           users.setSelectedIndex(0);              
                 try {
                     loadTable();
                 } catch (SQLException ex) {
                     Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
                 }
                 JOptionPane.showMessageDialog(null,"           Loan has been Succefully Added  !              ","Loan Information",JOptionPane.INFORMATION_MESSAGE);
                 
                 
                 
               
          
        
          
    }
 
 
        }


    }//GEN-LAST:event_jButton1ActionPerformed

    private void accounts_tableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_accounts_tableMouseReleased
try{
      search.setText("");
        chk1.setSelected(false);
        chk2.setSelected(false);
        int i = accounts_table.rowAtPoint(evt.getPoint());// TODO add your handling code here       
        
        String serial =(String) accounts_table.getValueAt(i,0);
        String name =( accounts_table.getValueAt(i,1)).toString();
        String username =(String) accounts_table.getValueAt(i,2);
        String pass =(String) accounts_table.getValueAt(i,3);
        String confirmpass =(String) accounts_table.getValueAt(i,4);
         

        t1.setText(serial);
           users.setSelectedItem(name);         
          books.setSelectedItem(username);
          ld.setDate(Date.valueOf(pass));
          rd.setDate(Date.valueOf(confirmpass));
       
       
        
        try {
            loadTable();
            // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
        }
}
catch(Exception ex )
{
    JOptionPane.showMessageDialog(null,"           Please  Select Only Single Row to Perform Operations  !          ","Loan Information",JOptionPane.WARNING_MESSAGE);
    try {
        loadTable();
        // TODO add your handling code here:
    } catch (SQLException ex1) {
        Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex1);
    }
        

}


      
    }//GEN-LAST:event_accounts_tableMouseReleased

    private void searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyReleased
search_data();
// TODO add your handling code here:
    }//GEN-LAST:event_searchKeyReleased

    private void chk2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk2ActionPerformed
chk1.setSelected(false);
search.grabFocus();// TODO add your handling code here:
    }//GEN-LAST:event_chk2ActionPerformed

    private void chk1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chk1ActionPerformed

chk2.setSelected(false);   
search.grabFocus();
// TODO add your handling code here:
    }//GEN-LAST:event_chk1ActionPerformed

    private void searchFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFocusLost
       
            chk2.setSelected(false);
            chk1.setSelected(false);
            search.setText("");
     
    }//GEN-LAST:event_searchFocusLost

    private void searchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFocusGained
t1.setText("00");   
 
 
                   load_themes();  load_users();
          
 books.setSelectedIndex(0);
           users.setSelectedIndex(0);        try {
            loadTable();
            
            
// TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_searchFocusGained

    private void accounts_tableFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_accounts_tableFocusLost
        try {
            loadTable();        // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_accounts_tableFocusLost

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
if(t1.getText().equals("00"))
{
    
            JOptionPane.showMessageDialog(null, "     Kindly Select Some Data Row From The Table To Update   . . .                   ", "Loan Information", JOptionPane.ERROR_MESSAGE);

}
else
{
 if(users.getSelectedIndex()==0  || books.getSelectedIndex()==0  )
        JOptionPane.showMessageDialog(null,"           Please Fill All The Required Fields   !              ","Loan Information",JOptionPane.ERROR_MESSAGE);
        else
        {
            
 {
        
        Statement st,st2,st1;
        
        try {
           
 int edit1=get_ids( "book", "title", books.getSelectedItem().toString()  );
   
 int copy_id=get_ids(  "copy", "book_id",String.valueOf(edit1));
 
 int userId=get_ids(  "user", "name", users.getSelectedItem().toString()  );
 
 
 int b_id=0;
 
 
 SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
    String fdate=df1.format(ld.getDate());
    
    SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
    String tdate=df2.format(rd.getDate());
    
 
            st = con.createStatement();
            st.executeUpdate("UPDATE  loan set user_id='"+userId+"', copy_id='"+copy_id+"', loan_date='"+fdate+"',return_date='"+tdate+"' where loan_id ='"+t1.getText()+"'");
            
            
            
          
        } catch (Exception ex) {
            Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        t1.setText("00");
        
   
        load_themes();  load_users();
       
 books.setSelectedIndex(0);
           users.setSelectedIndex(0);       
        try {
            loadTable();
        } catch (SQLException ex) {
            Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
        }
        JOptionPane.showMessageDialog(null,"           Loan has been Succefully Updated  !              ","Loan Information",JOptionPane.INFORMATION_MESSAGE);
        
        
        
    }
        
        }       }         }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
   if(t1.getText().equals("00"))
{
    
            JOptionPane.showMessageDialog(null, "     Kindly Select Some Data Row From The Table To Delete   . . .                   ", "Copy Information", JOptionPane.ERROR_MESSAGE);

}
else
if(accounts_table.getRowCount()== 1 && (t1.getText().equals("00")==false) )
{
    delete(1);
}    
else
{
delete();    
}

   

  // TODO add your handling code here:        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
try { 
             loadTable();
         } catch (SQLException ex) {
             Logger.getLogger(tests_panel.class.getName()).log(Level.SEVERE, null, ex);
         }
         if(accounts_table.getRowCount()==0)
         {
          JOptionPane.showMessageDialog(null, "All  Loans Information Has Already Deleted From The DataBase .                  ", "Loans Information", JOptionPane.INFORMATION_MESSAGE);

         }
         else{                                        
int i = JOptionPane.showConfirmDialog(null,"Do you Really Want To Delete All The Loan       ?  ","Loan Information",JOptionPane.YES_NO_OPTION);
 if(i == JOptionPane.YES_OPTION )
 {
    try {
        Statement st;
        st = con.createStatement();
        st.executeUpdate("DELETE FROM loan");
               

         t1.setText("00");
       
    
     load_themes();  load_users();
        
 books.setSelectedIndex(0);
           users.setSelectedIndex(0);        search.setText("");
 
        chk1.setSelected(false);
         chk2.setSelected(false);
        loadTable();
 
        JOptionPane.showMessageDialog(null, "All Loan  Has Been Deleted From The DataBase SuccessFully.                 ", "Loan Information", JOptionPane.INFORMATION_MESSAGE);
    } catch (SQLException ex) {
        Logger.getLogger(accounts_information_panel.class.getName()).log(Level.SEVERE, null, ex);
    }
        

   
 }
 else;      
         }// TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void booksKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_booksKeyPressed
        if(evt.getKeyChar()== evt.VK_ENTER)
        t1.grabFocus();        // TODO add your handling code here:
    }//GEN-LAST:event_booksKeyPressed

    private void usersKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_usersKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_usersKeyPressed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        try {
            new avaiable_books().setVisible(true);        // TODO add your handling code here:
        } catch (SQLException ex) {
            Logger.getLogger(loan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void usersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usersActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usersActionPerformed

    private void accounts_tableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_accounts_tableMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_accounts_tableMousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JTable accounts_table;
    public static javax.swing.JComboBox<String> books;
    private javax.swing.JCheckBox chk1;
    private javax.swing.JCheckBox chk2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private com.toedter.calendar.JDateChooser ld;
    private com.toedter.calendar.JDateChooser rd;
    private javax.swing.JTextField search;
    private javax.swing.JLabel t1;
    public static javax.swing.JComboBox<String> users;
    // End of variables declaration//GEN-END:variables
}
